//
//  ContactAtOnceMessaging.h
//  Liveperson
//
//  Created by Aaron Bratcher on 11/13/17.
//  Copyright © 2017 Liveperson. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ContactAtOnceMessaging.
FOUNDATION_EXPORT double ContactAtOnceMessagingVersionNumber;

//! Project version string for Liveperson.
FOUNDATION_EXPORT const unsigned char ContactAtOnceMessagingVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ContactAtOnceMessaging/PublicHeader.h>

#import <ContactAtOnceMessaging/LPBSMobileProvision.h>
#import <ContactAtOnceMessaging/ExceptionCatcher.h>
